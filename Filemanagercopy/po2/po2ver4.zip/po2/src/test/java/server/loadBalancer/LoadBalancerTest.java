package server.loadBalancer;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.PriorityBlockingQueue;

import static org.hamcrest.core.Is.is;
import static org.mockito.Matchers.any;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.verifyNew;
import static org.powermock.api.mockito.PowerMockito.whenNew;

@RunWith(PowerMockRunner.class)
@PrepareForTest(fullyQualifiedNames = "server.*")
public class LoadBalancerTest
    {
    Path path;
    LoadBalancer loadBalancer;
    LoadBalancerSave task;
    LoadBalancerTask dataForTask;

    @Before
    public void setUp() throws Exception
        {
        dataForTask = new LoadBalancerTask("user", "file", null);

        path = Paths.get(System.getProperty("user.home")).resolve("test");

        loadBalancer = new LoadBalancer(new ArrayList<Path>()
            {{
            add(path);
            }});

        task = mock(LoadBalancerSave.class);
        whenNew(LoadBalancerSave.class).withArguments(any(LinkedBlockingQueue.class), any(PriorityBlockingQueue.class)).thenReturn(task);
        }

    @Test
    public void shouldCreateOneSaveHandler() throws Exception
        {
        loadBalancer.saveFile(dataForTask);
        verifyNew(LoadBalancerSave.class).withArguments(any(LinkedBlockingQueue.class),
                any(PriorityBlockingQueue.class));
        }

    @Test
    public void shouldReturn2AsPriorityBecauseUserSaveFileTwoTimes()
        {
        loadBalancer.saveFile(dataForTask);
        loadBalancer.saveFile(dataForTask);
        Assert.assertThat(dataForTask.getPriority(), is(2));
        }

    @Test
    public void shouldReturn0AsPriority()
        {
        loadBalancer.saveFile(dataForTask);
        Assert.assertThat(dataForTask.getPriority(), is(1));
        }

    @Test
    public void shouldReturn0AsCountBecauseOfSaveFileFunction()
        {
        loadBalancer.getCount("user");
        loadBalancer.getCount("user");
        loadBalancer.saveFile(dataForTask);
        Integer count = loadBalancer.getCount("user");
        Assert.assertThat(count, is(0));
        }

    @Test
    public void shouldReturn2AsCount()
        {
        loadBalancer.getCount("user");
        loadBalancer.getCount("user");
        Integer count = loadBalancer.getCount("user");
        Assert.assertThat(count, is(2));
        }

    @Test
    public void shouldReturn1AsCount()
        {
        loadBalancer.getCount("user");
        loadBalancer.getCount("user2");
        Integer count = loadBalancer.getCount("user");
        Integer count2 = loadBalancer.getCount("user2");
        Assert.assertThat(count, is(1));
        Assert.assertThat(count2, is(1));
        }

    @Test
    public void shouldReturnTrueBecauseUser1HasBiggerPriority()
        {
        LoadBalancerTask data1 = new LoadBalancerTask("user", "file", null);
        LoadBalancerTask data2 = new LoadBalancerTask("user", "file", null);
        LoadBalancerTask data3 = new LoadBalancerTask("user1", "file", null);

        loadBalancer.saveFile(data1);
        loadBalancer.saveFile(data2);
        loadBalancer.saveFile(data3);

        Assert.assertTrue(data3.compareTo(data2) > 0);
        }

    @Test
    public void shouldReturnFalseBecauseUser1DoesntHaveBiggerPriority()
        {
        LoadBalancerTask data1 = new LoadBalancerTask("user", "file", null);
        LoadBalancerTask data2 = new LoadBalancerTask("user", "file", null);
        LoadBalancerTask data3 = new LoadBalancerTask("user1", "file", null);
        LoadBalancerTask data4 = new LoadBalancerTask("user1", "file", null);
        LoadBalancerTask data5 = new LoadBalancerTask("user1", "file", null);

        loadBalancer.saveFile(data1);
        loadBalancer.saveFile(data2);
        loadBalancer.saveFile(data3);
        loadBalancer.saveFile(data4);
        loadBalancer.saveFile(data5);

        Assert.assertTrue(data5.compareTo(data2) < 0);
        }
    }
