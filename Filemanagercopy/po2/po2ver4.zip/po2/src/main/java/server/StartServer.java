package server;

import server.gui.ServerGui;

/**
 * Klasa uruchomieniowa dla serwera
 */
public class StartServer
    {
    public static void main(String[] args)
        {
        try
            {
            new Thread(new ServerWaitForClient()).start();
            ServerGui gui = new ServerGui();

            new Thread(() ->
            {
            try
                {
                while (true)
                    {
                    gui.refresh();
                    gui.setField("refresh listy");
                    Thread.sleep(4000);
                    }
                }
            catch (Exception e)
                {
                e.printStackTrace();
                }
            }).start();

            }
        catch (Exception e)
            {
            e.printStackTrace();
            }
        }
    }
