package server.loadBalancer;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 * Klasa realizuje zapis jednego pliku, pobiera sciezki do serwerow i pule taskow.
 */
public class LoadBalancerSave implements Runnable
    {
    private LinkedBlockingQueue<Path> paths;
    private PriorityBlockingQueue<LoadBalancerTask> tasks;
    private OutputStream out;
    private InputStream in;
    byte[] bytes = new byte[4096];

    /**
     * @param paths Lista serwerow
     * @param tasks Lista zadani do zapisania
     */
    public LoadBalancerSave(LinkedBlockingQueue<Path> paths, PriorityBlockingQueue<LoadBalancerTask> tasks)
        {
        this.paths = paths;
        this.tasks = tasks;
        }

    @Override
    public void run()
        {
        try
            {
            Path path = paths.take();//czeka az bedzie woly server
            LoadBalancerTask task = tasks.take();//pobranie taska o naj. piorytecie
            Path filePath = makeFile(path, task);
            in = task.getSocket().getInputStream();
            out = null;

            if (!LoadBalancer.fileExist(task.getUserName(), task.getFileName()))
                {
                saveAndCopy(path, task, filePath);
                }
            else if (task.getSendTo().length() > 0 && !LoadBalancer.fileExist(task.getSendTo(),
                    task.getFileName()))
                {
                saveOnlyToOtherUser(path, task);
                }

            if (out != null)
                {
                out.close();
                }
            paths.put(path);
            task.getSocket().close();
            task.getDone().set(true);
            }
        catch (Exception e)
            {
            e.printStackTrace();
            Logger.getAnonymousLogger().log(Level.WARNING, "problem with save");
            }

        }

    private void saveOnlyToOtherUser(Path path, LoadBalancerTask task) throws IOException
        {
        out =
                Files.newOutputStream(path.resolve(task.getSendTo()).resolve(task.getFileName()));
        writeFromUser();
        LoadBalancer.addUserFilesRegister(task.getSendTo(),
                path.resolve(task.getSendTo()).resolve(task.getFileName()));
        }

    private void saveAndCopy(Path path, LoadBalancerTask task, Path filePath) throws IOException
        {
        out = Files.newOutputStream(filePath, StandardOpenOption.CREATE);
        writeFromUser();
        LoadBalancer.addUserFilesRegister(task.getUserName(), filePath);

        if (task.getSendTo().length() > 0 && !LoadBalancer.fileExist(task.getSendTo(), task.getFileName()))
            {
            Files.copy(filePath, path.resolve(task.getSendTo()).resolve(task.getFileName()),
                    StandardCopyOption.REPLACE_EXISTING);
            LoadBalancer.addUserFilesRegister(task.getSendTo(), path.resolve(task.getSendTo()).resolve(task.getFileName()));
            }
        }

    private void writeFromUser() throws IOException
        {
        int count;//ilosc danych odczytu

        while ((count = in.read(bytes)) > 0)
            {
            out.write(bytes, 0, count);
            }
        }

    private Path makeFile(Path path, LoadBalancerTask task) throws IOException
        {
        if (!Files.exists(path.resolve(task.getUserName())))
            {
            Files.createDirectories(path.resolve(task.getUserName()));
            }

        if (!Files.exists(path.resolve(task.getSendTo())) && task.getSendTo().length() > 0)
            {
            Files.createDirectories(path.resolve(task.getSendTo()));
            }

        Path filePath = path.resolve(task.getUserName()).resolve(task.getFileName());

        return filePath;
        }
    }
