package user;

import java.io.IOException;

public interface User
    {

    String getName();

    boolean refreshFileList() throws IOException;

    boolean refreshServerFileList() throws IOException, InterruptedException;

    boolean getUsersFromServer();

    boolean sendFileToServer(ClientFile myFile);

    boolean sendFileToServer(String name, String to);
    }
